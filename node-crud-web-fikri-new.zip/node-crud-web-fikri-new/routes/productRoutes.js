const express = require('express');
const router = express.Router();
const db = require('../config/database');

router.get('/', async (req, res, next) => {
try {
const [products] = await db.execute(
'SELECT * FROM products ORDER BY created_at DESC'
);

res.render('index', {
title: 'Daftar Produk',
products: products,
success: req.query.success

});
} catch (error) {
next(error);
}
});

router.get('/add', (req, res) => {
res.render('add-product', {
title: 'Tambah Produk Baru',
product: {}
});
});

router.post('/add', async (req, res, next) => {
try {
const { name, price, description } = req.body;

if (!name || !name.trim()) {
return res.redirect('/add?error=Nama produk harus diisi');
}

if (!price || isNaN(price) || parseFloat(price) <= 0) {
return res.redirect('/add?error=Harga harus angka positif');
}

const [result] = await db.execute(
'INSERT INTO products (name, price, description) VALUES (?, ?, ?)',
[name.trim(), parseFloat(price), description || null]
);

res.redirect('/?success=Produk berhasil ditambahkan');
} catch (error) {
next(error);
}
});

router.get('/edit/:id', async (req, res, next) => {
try {
const productId = parseInt(req.params.id);

if (!productId || isNaN(productId)) {
return res.redirect('/?error=ID produk tidak valid');
}

const [results] = await db.execute(
'SELECT * FROM products WHERE id = ?',
[productId]
);

if (results.length === 0) {

return res.redirect('/?error=Produk tidak ditemukan');
}

res.render('edit-product', {
title: 'Edit Produk',
product: results[0]
});
} catch (error) {
next(error);
}
});

router.post('/edit/:id', async (req, res, next) => {
try {
const productId = parseInt(req.params.id);
const { name, price, description } = req.body;

if (!productId || isNaN(productId)) {
return res.redirect('/?error=ID produk tidak valid');
}

if (!name || !name.trim()) {
return res.redirect(`/edit/${productId}?error=Nama produk harus
diisi`);
}

if (!price || isNaN(price) || parseFloat(price) <= 0) {
return res.redirect(`/edit/${productId}?error=Harga harus angka
positif`);
}

const [result] = await db.execute(
'UPDATE products SET name = ?, price = ?, description = ? WHERE id = ?',
[name.trim(), parseFloat(price), description || null, productId]
);

if (result.affectedRows === 0) {
return res.redirect('/?error=Produk tidak ditemukan');
}

res.redirect('/?success=Produk berhasil diupdate');
} catch (error) {
next(error);
}
});

router.get('/delete/:id', async (req, res, next) => {
try {
const productId = parseInt(req.params.id);

if (!productId || isNaN(productId)) {

return res.redirect('/?error=ID produk tidak valid');
}

const [result] = await db.execute(
'DELETE FROM products WHERE id = ?',
[productId]
);

if (result.affectedRows === 0) {
return res.redirect('/?error=Produk tidak ditemukan');
}

res.redirect('/?success=Produk berhasil dihapus');
} catch (error) {
next(error);
}
});

module.exports = router;

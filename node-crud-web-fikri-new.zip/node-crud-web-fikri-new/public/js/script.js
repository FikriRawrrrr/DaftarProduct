document.addEventListener('DOMContentLoaded', function() {
const forms = document.querySelectorAll('.needs-validation');

Array.from(forms).forEach(form => {
form.addEventListener('submit', function(event) {
if (!form.checkValidity()) {
event.preventDefault();
event.stopPropagation();
}
form.classList.add('was-validated');
}, false);
});

const alerts = document.querySelectorAll('.alert');
alerts.forEach(alert => {
setTimeout(() => {
const bsAlert = new bootstrap.Alert(alert);
bsAlert.close();
}, 5000);
});

const deleteButtons = document.querySelectorAll('a[href*="/delete/"]');
deleteButtons.forEach(button => {

button.addEventListener('click', function(e) {
if (!confirm('Apakah Anda yakin ingin menghapus produk ini?'))
{
e.preventDefault();
}
});
});
});

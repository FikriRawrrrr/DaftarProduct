require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

const productRoutes = require('./routes/productRoutes');

app.use(express.urlencoded({ extended: true }));

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use((req, res, next) => {
res.locals.success = req.query.success;
res.locals.error = req.query.error;
next();
});

app.use('/', productRoutes);

app.use((err, req, res, next) => {
console.error('❌ Server Error:', err.stack);
res.status(500).render('error', {
title: 'Server Error',
error: process.env.NODE_ENV === 'development' ? err.message : 'Terjadi kesalahan pada server'
});
});

app.use((req, res) => {
res.status(404).render('404', {
title: 'Halaman Tidak Ditemukan'

});
});

app.listen(PORT, () => {
console.log(`🚀 Server running at http://localhost:${PORT}`);
console.log(`📊 Database:
${process.env.DB_NAME}@${process.env.DB_HOST}:${process.env.DB_PORT}`);
console.log(`👨‍💻 Mode: ${process.env.NODE_ENV}`);
console.log(`🔄 Development mode: npm run dev`);
});
